package impostos;

public class Tributavel {
    
    double calculaTributos();
}
