package impostos;

public interface SeguroDeVida {
    
    public double seguroDeVida(double valor);
}
