package funcionario;

public class Presidente extends Funcionario {

	public Presidente(String nome, int senha, int cpf, String cargo) {
		this.nome = nome;
		this.senha = senha;
		this.cpf = cpf;
		this.cargo = cargo;
	}
}
