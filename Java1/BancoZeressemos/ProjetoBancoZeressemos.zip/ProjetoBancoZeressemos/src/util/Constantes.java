package util;

public class Constantes {
	
	static public final String CARGO_GERENTE = "1";
	static public final String CARGO_DIRETOR = "2";
	static public final String CARGO_PRESIDENTE = "3";
	
}
